d3 = {version: "2.10.2"}; // semver
