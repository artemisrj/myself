d3_transitionPrototype.transition = function() {
  return this.select(d3_this);
};
